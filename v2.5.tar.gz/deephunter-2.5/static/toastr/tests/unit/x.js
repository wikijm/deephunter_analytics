    test('test test', 1, function () {
        ok(1 === 1, '1 equals 1');
    });
